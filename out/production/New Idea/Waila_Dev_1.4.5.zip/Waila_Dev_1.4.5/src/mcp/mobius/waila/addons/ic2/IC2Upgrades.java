package mcp.mobius.waila.addons.ic2;

public class IC2Upgrades {
	public int transform   = 0;
	public int storage     = 0;
	public int overclocker = 0;
}
