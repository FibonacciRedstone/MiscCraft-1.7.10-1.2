package mcp.mobius.waila.api;

public interface IWailaDataProvider extends IWailaBlock{
}
